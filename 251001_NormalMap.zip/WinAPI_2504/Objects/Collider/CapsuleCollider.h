#pragma once

class CapsuleCollider
{

};