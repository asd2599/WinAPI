#include "Framework.h"
#include "AStarScene.h"

AStarScene::AStarScene()
{
}

AStarScene::~AStarScene()
{
}

void AStarScene::Update()
{
}

void AStarScene::Render()
{
}
